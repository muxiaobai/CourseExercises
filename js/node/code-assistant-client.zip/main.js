const {BrowserWindow, Menu, Tray, ipcMain, app, dialog} = require('electron');
const fs = require('fs');
const AutoLaunch = require('auto-launch');

// log4js
const log4js = require('log4js');
log4js.configure(JSON.parse(fs.readFileSync(__dirname + '/app/log4js.conf')));
const lg = log4js.getLogger('file');
// 窗口
let winMain, winLogin, winSettings, winAbout, tray;

// 全局共享配置参数
global.lg = lg;
global.FORP = JSON.parse(fs.readFileSync(__dirname + '/app/settings.conf'));
// 重置Session标识
global.FORP.p1 = '';

// Single Instance
const isSecondInstance = app.makeSingleInstance((args, workingDirectory) =>
{
  lg.debug('args:' + args);

  if (winMain)
  {
    if (winMain.isMinimized())
    {
      winMain.restore();
    }

    winMain.focus();

    // 处理协议（发送消息方式）
    if (args.length >= 2)
    {
      lg.debug('浏览器协议参数：' + args[1]);
      winMain.webContents.send('browser-cmd', args[1]);
    }
  }
});

if (isSecondInstance)
{
  app.quit();
  return;
}

/**
 * 初始化应用
 */
function init()
{
  lg.info('Version：' + global.FORP.version + ' Host：' + global.FORP.host);

  // 创建登录窗口
  winLogin = new BrowserWindow(
  {
    width: 400, height: 300, resizable: false, frame: false, icon: __dirname + '/app/img/forp.ico'
  });
  winLogin.loadURL('file://' + __dirname + '/app/login.html');
  // winLogin.webContents.openDevTools();
  winLogin.show();

  // 创建主窗口.
  winMain = new BrowserWindow(
  {
    width: 1000, height: 550, minWidth: 1000, minHeight: 550, frame: false, show: false, icon: __dirname + '/app/img/forp.ico'
    // webPreferences: {nodeIntegration: false} // nodeIntegrationInWorker: true - 开启Node.js特性功能
  });
  winMain.loadURL('file://' + __dirname + '/app/index.html');
  // winMain.webContents.openDevTools();

  // 注册系统托盘
  // TODO 双机图标打开主窗口
  tray = new Tray(__dirname + '/app/img/forp.ico');
  var menuTray = Menu.buildFromTemplate(
  [
    {label: '打开工作助手', icon: __dirname + '/app/img/open.png', click: () =>
    {
      // 如果当前未登录, 则显示登录窗口; 如果当前已登录, 则显示主窗口
      // winMain.isVisible() ? winMain.hide() : winMain.show()
      winMain.show();
    }},
    {label: '-', type: 'separator'},
    {label: '参数设置', icon: __dirname + '/app/img/settings.png', click: showSettingsWin},
    {label: '检查新版本', icon: __dirname + '/app/img/upgrade.png', click: () =>
    {
      winMain.webContents.send('check-new-version');
    }},
    {label: '关于我们', icon: __dirname + '/app/img/about.png', click: showAboutWin},
    {label: '-', type: 'separator'},
    {label: '退出', icon: __dirname + '/app/img/quit.png', click: () => {app.quit();}}  // TODO 发送退出事件，确保相应事件可以正确执行
  ]);
  tray.setToolTip('西点信息工作底稿上传助手');
  tray.setContextMenu(menuTray);

  // forp-fa协议监听
  app.setAsDefaultProtocolClient("forp-fa", process.execPath);
  lg.debug('启动参数：' + process.argv);

  lg.info('App启动、初始化就绪!');
}

//===========================================================
//		app事件区域
//===========================================================

// 初始化应用程序
app.on('ready', init);

// 退出前事件
app.on('before-quit', () =>
{
  tray = null;

  // 保存上传/下载任务
  winMain.show();
  winMain.webContents.send('before-quit');

  // 保存配置参数
  fs.writeFileSync(__dirname + '/app/settings.conf', JSON.stringify(FORP));
  lg.info('配置参数保存成功！');

  lg.info('App结束运行！\r\n');
});

/**
 * 打开参数设值Window
 */
function showSettingsWin()
{
  if (null == winSettings)
  {
    winSettings = new BrowserWindow(
    {
      width: 420, height: 391, resizable: false, frame: false, show: false,
      parent: winMain, modal: true, icon: __dirname + '/app/img/forp.ico'
    });
    winSettings.loadURL('file://' + __dirname + '/app/settings.html');
  }

  winSettings.show();
  // winSettings.webContents.openDevTools();
}

/**
 * 打开关于Window
 */
function showAboutWin()
{
  if (null == winAbout)
  {
    winAbout = new BrowserWindow(
    {
      width: 332, height: 350, resizable: false, frame: false, show: false,
      parent: winMain, modal: true, icon: __dirname + '/app/img/forp.ico'
    });
    winAbout.loadURL('file://' + __dirname + '/app/about.html');
  }

  winAbout.show();
}

//===========================================================
//		ipcMain异步通信
//===========================================================

// 主窗口：最小化
ipcMain.on('hide-window', (event, arg) =>
{
  winMain.minimize();
});

// 主窗口：最大化
ipcMain.on('show-window', (event, arg) =>
{
  winMain.maximize();
});

// 主窗口：还原
ipcMain.on('unmaximize-window', (event, arg) =>
{
  winMain.unmaximize();
});

// 主窗口：关闭
ipcMain.on('window-main-closed', (event, arg) =>
{
  // 在 macOS 上，除非用户用 Cmd + Q 确定地退出，否则绝大部分应用及其菜单栏会保持激活。
  if (process.platform !== 'darwin')
  {
    app.quit();
  }
});

// 登陆：显示
ipcMain.on('window-login-show', (event, arg) =>
{
  winLogin.show();
});

// 登陆：成功
ipcMain.on('login-success', (event, arg) =>
{
  // 刷新用户等信息
  winMain.webContents.send('login-success');
  winLogin.hide();
  winMain.show();

  if (process.argv.length >= 2)
  {
    // 给winMain发送处理消息
    lg.debug('浏览器协议参数：' + process.argv[1]);
    winMain.webContents.send('browser-cmd', process.argv[1]);
  }
});

// 登陆：窗口关闭
ipcMain.on('window-login-closed', (event, arg) =>
{
  winLogin.hide();
  winMain.show();
});

// 参数设置：显示
ipcMain.on('window-settings-show', (event, arg) =>
{
  showSettingsWin();
});

// 参数设置：关闭
ipcMain.on('window-settings-close', (event, arg) =>
{
  winSettings.hide();

  // 开机自启动
  var al = new AutoLaunch({name: '西点工作底稿上传助手', path: process.argv[0]});
  if (FORP.autoStart)
  {
    al.enable();
  }
  else
  {
    al.disable();
  }

  // 保存配置参数
  fs.writeFileSync(__dirname + '/app/settings.conf', JSON.stringify(FORP));
  lg.info('配置参数保存成功！');
});

// 关于我们：显示
ipcMain.on('window-about-closed', (event, arg) =>
{
  winAbout.hide();
});

// 自动更新：有新版本
ipcMain.on('new-version', (event, newVersion) =>
{
  winMain.webContents.send('new-version', newVersion);
});

// 自动更新：显示
ipcMain.on('window-update-show', (event, newVersion) =>
{
  lg.debug('新版本：' + newVersion);
  var winUpdate =  new BrowserWindow(
  {
    width: 500, height: 180, resizable: false, frame: false, show: true, icon: __dirname + '/app/img/forp.ico', parent: winMain, modal: true
  });
  winUpdate.loadURL('file://' + __dirname + '/app/update.html');

  // 页面加载完成后触发消息
  winUpdate.webContents.on('did-finish-load', function()
  {
    winUpdate.webContents.send('new-version', newVersion);
  });
});

// 自动更新：重启应用
ipcMain.on('app-restart', (event, arg) =>
{
  lg.info('重启App...\r\n');
  app.relaunch();
  app.exit();
});