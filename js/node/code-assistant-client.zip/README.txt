安装node 安装npm
安装yarn yarn i -g yarn
运行 yarn init
yarn start
yarn pkg-win
yarn pkg-mac