/**
 * 通用js函数
 *
 * Copyright © 2018 FORP Co., LTD
 * All Rights Reserved.
 */

// 文件尺寸单位
var FILE_SIZE_UNITS = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];

//------------------------------------------------------------------------------------------
//		JS Object
//------------------------------------------------------------------------------------------

// TODO 系统启动时报脚本语法错误
// /**
//  * String类添加startsWith方法
//  */
// String.prototype.startsWith = function(val)
// {
// 	return (this.match('^' + val) == val);
// }

String.prototype.startWith = function(str)
{ 
	var reg = new RegExp("^" + str); 
	return reg.test(this); 
}

// /**
//  * String类添加endsWith方法
//  */
// String.prototype.endsWith = function(val)
// {
// 	return (this.match(val + '$') == val);
// }

/**
 * String类添加replaceAll方法
 */
String.prototype.replaceAll = function(searchValue, newValue)
{
	return this.replace(new RegExp(searchValue, "gm"), newValue);
}

/** 
 * Date类添加format方法
 */  
Date.prototype.format = function(format)
{
	/**
	 * eg:format="yyyy-MM-dd hh:mm:ss"; 
	 */  
	var o =
	{
		"M+" : this.getMonth() + 1, // month  
		"d+" : this.getDate(), // day  
		"h+" : this.getHours(), // hour  
		"m+" : this.getMinutes(), // minute  
		"s+" : this.getSeconds(), // second  
		"q+" : Math.floor((this.getMonth() + 3) / 3), // quarter  
		"S" : this.getMilliseconds()  
		// millisecond  
	}

	if (/(y+)/.test(format))
		format = format.replace(RegExp.$1, (this.getFullYear() + "").substr(4	- RegExp.$1.length));  

	for (var k in o)
	{
		if (new RegExp("(" + k + ")").test(format))
			format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
  }

	return format;
}

/**
 * 格式化毫秒日期为指定格式
 * 
 * @param {long} 		millisec 毫秒值
 * @param {string} 	fmt			 日期格式（yyyy-MM-dd hh:mm:ss）
 */
function formatDate(millisec, fmt)
{
	var date = new Date();
	date.setTime(millisec);

	return date.format(fmt);
}
//------------------------------------------------------------------------------------------
//		jQuery
//------------------------------------------------------------------------------------------

// Global settings
$.ajaxSetup(
{
	type: 'POST', dataType: 'json', headers: {'powed-by': 'Forp'}, timeout: 3600 * 1000, complete: function(request, textStatus)
	{
		// console.log(req);
		// console.log(textStatus);
		if (request.responseJSON)
		{
			if (401 == request.responseJSON.code)
			{
				// TODO 调用exe的登陆界面
				alert('您长时间没有操作，需要重新验证您的账号安全。\r\n请重新登录系统！');
			}
			else if (500 == request.responseJSON.code)
			{
				alert(request.responseJSON.msg);
			}
		}
	}
});

/**
 * 全局Loading
 */
var $RequestCount = 0;
var $Loading = $(".interruption", top.document);

$(document)
	.ajaxStart(function(event)
	{
		$RequestCount++;
		$Loading.show();
	})
	.ajaxComplete(function()
	{
		$RequestCount--;
		if ($RequestCount <= 0)
		{
			$Loading.fadeOut(500);
		}
	});

//------------------------------------------------------------------------------------------
//		Common Function
//------------------------------------------------------------------------------------------

/**
 * 根据文件后缀名转换对应的图标css名称
 */
function getFileIcon(filePath)
{
	if (filePath)
	{
		var file = filePath.toLowerCase();
		if (file.endsWith('.doc') || file.endsWith('.docx') || file.endsWith('.rtf'))
			return 'icon-word';
		else
			if (file.endsWith('.pdf'))
				return 'icon-pdf';
			else
				if (file.endsWith('.rar'))
					return 'icon-rar';
				else
					if (file.endsWith('.zip'))
						return 'icon-zip';
					else
						if (file.endsWith('.xls') || file.endsWith('.xlsx') || file.endsWith('.csv'))
							return 'icon-excel';
						else
							if (file.endsWith('.ppt') || file.endsWith('.pptx'))
								return 'icon-ppt';
	}

	// 默认图标
	return 'icon-unknown';
}

/**
 * UUID
 */
function getUUID()
{
	return ('xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c)
	{
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r&0x3|0x8);
		return v.toString(16);
	}));
}

/**
 * 文件大小智能格式化
 *
 * @param {Object} fileSize
 */
function formatFileSize(fileSize)
{
	var size = fileSize;
	
	var result = '';
	for (var i = 0; size > 1; size /= 1024, i++)
	{
		result = size.toFixed(2) + " " + FILE_SIZE_UNITS[i];
	}

	return result;
}

/**
 * 格式化秒值为时分秒格式
 *
 * @param {long} seconds	秒数
 */
function formatSeconds(seconds)
{
	var hms;
	if(seconds > 0)
	{
		var hour = Math.floor(seconds / 3600);
		var min = Math.floor(seconds / 60) % 60;
		var sec = Math.floor(seconds) % 60;
		hms = (hour < 10 ? '0' : '') + hour + ':';
		hms += (min < 10 ? '0' : '') + min + ':';
		hms += (sec < 10 ? '0' : '') + sec;

		if ('00:00:00' == hms)
		{
			hms = '00:00:01';
		}
	}
	else
	{
		hms = '00:00:00';
	}

	return hms;
}

/**
 * 吐司提示信息
 *
 * @param style   样式
 * @param title   标题
 * @param msg			消息
 */
function toast(style, title, msg)
{
	toastr.options = {closeButton: true, debug: false, newestOnTop: true, progressBar: true, positionClass: "toast-bottom-right", preventDuplicates: true, onclick: null, showDuration: 0, timeOut: 5 * 1000};	
	toastr[style](msg, title);
}

/**
 * 回车键执行查询方法 [适用于工具栏中的查询条件回车键直接查询功能]
 *
 * @param event     回车键事件
 * @param searchFn	search function
 */
function enterKeySearch(event, searchFn)
{
	if (13 == event.keyCode)
	{
		searchFn.call(this);
	}
}