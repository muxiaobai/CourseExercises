/**
 * Forp大文件断点上传类
 *
 * Copyright © 2018 FORP Co., LTD
 * All Rights Reserved.
 */

// **注意**：Tiny-Worker只能执行NodeJs环境，普通Javascript语法无法执行

const fs = require('fs');
const request  = require('request');
const sleep = require('thread-sleep');
// Log4js
const log4js = require('log4js');
var lg = null;
// 全局变量
var FORP, task, endPosition, errorTimes = 0;

/**
 * 接收主线程消息
 */
onmessage = function(event)
{
	// log4js
	if (null == lg)
	{
		log4js.configure(JSON.parse(fs.readFileSync(event.data.dirname + '/log4js.conf')));
		lg = log4js.getLogger('file');
	}

	// FORP信息
	if (event.data.FORP)
	{
		FORP = event.data.FORP;
	}

	// task信息
	if (event.data.task)
	{
		task = event.data.task;
	}

	// 命令处理
	if ('start' == event.data.cmd)
	{
		lg.info('↑↑↑↑↑ ' + task.filePath + '[' + task.id + ']');
		uploadTrunk();

		// TODO 打开文件，防止其它进程进行写入新内容，移动文件等操作
		// fs.open(task.filePath, 'a+', function(err, fd)
		// {
		// 	uploadTrunk(function()
		// 	{
		// 		fs.close(fd, function()
		// 		{
		// 			lg.debug('释放文件: ' + fd);
		// 		});
		// 	});
		// });
	}
	else if ('pause' == event.data.cmd)
	{
		// 暂停
		task.status = 'pause';
	}
	else if ('remove' == event.data.cmd)
	{
		// 删除
		task.status = 'remove';
	}
	else
	{
		lg.warn('无效的上传指令：' + event.data);
	}
}

/**
 * 上传文件片段
 */
function uploadTrunk()
{
	try
	{
		if ('running' != task.status)
		{
			postMessage({cmd: 'statusChanged', task: task});
			lg.info('上传Worker结束运行[' + task.id + ']' + task.status);
			lg = null;

			return;
		}

		// 分段上传
		if (task.position >= task.fileSize)
		{
			// 已上传完成
			lg.info('文件上传成功：' + task.filePath + ' ' + task.fileSize + ' ' + 
			(task.finishTime - task.startTime) / 1000 + '秒 ' + (task.fileSize / ((task.finishTime - task.startTime) / 1000)) + '/秒');

			lg = null;
			task.status = 'finished';
			// 文件上传完成
			postMessage({cmd: 'finished', task: task});
			return;
		}

		lg.info('↑↑[' + task.id + ']:' + task.position + '->' + task.fileSize);

		// Base64编码方式
		// var Buffer = require('buffer').Buffer;
		// var buffer = Buffer.alloc(FORP.uploadTrunkSize);
		// try
		// {
		// 	var fd = fs.openSync(task.filePath , 'r');
		// 	readed = fs.readSync(fd, buffer, 0, FORP.uploadTrunkSize, task.position);
		// }
		// finally
		// {
		// 	fs.closeSync(fd);
		// }
		// 
		// var params =
		// {
		// 	url: FORP.host + '/fileassistant/upload/' + task.id,
		// 	headers: {'powed-by': 'Forp'}, method: 'POST', json: true,
		// 	formData: {p1: FORP.p1, position: task.position, trunkSize: readed, trunk: buffer.toString('base64')}
		// };
		// buffer = null;

		// 结束位置
		endPosition = (task.position + FORP.uploadTrunkSize) >= task.fileSize ? (task.fileSize - 1) : (task.position + FORP.uploadTrunkSize);
		// 请求参数
		var	params =
		{
			url: FORP.host + '/fileassistant/upload/' + task.id, headers: {'powed-by': 'Forp'}, method: 'POST', json: true,
			formData:
			{
				p1: FORP.p1, position: task.position, // trunkSize: readed,
				trunk:
				{
					value: fs.createReadStream(task.filePath, {start: task.position, end: endPosition, autoClose: true}),
					options: {filename: task.fileName}
				}
			}
		};

		// 发送HTTP请求
		request(params, function(err, rsp, body)
		{
			// lg.debug(body);
			if (body && body.code && 200 == body.code)
			{
				if (0 == task.position)
				{
					// 记录服务器端开始上传的时间：减去1秒模拟为客户端实际添加文件的时间，防止只有一段时用时为0的问题。
					task.startTime = body.data.serverTime - 100;
				}

				// 更新服务器端的完成时间
				preFinishTime = task.finishTime;
				task.finishTime = body.data.serverTime;
				if (-1 == preFinishTime)
				{
					preFinishTime = task.startTime;
				}

				// 计算已上传的大小
				var readed = 0;
				if (task.position + FORP.uploadTrunkSize > task.fileSize)
				{
					readed = task.fileSize - task.position;
				}
				else
				{
					readed = FORP.uploadTrunkSize;
				}

				// 后移文件上传进度
				task.position = task.position + readed;
				// 刷新上传进度
				postMessage({cmd: 'progress', task: task, preFinishTime: preFinishTime, finished: readed});
				return uploadTrunk();
			}
			else
			{
				// 重试3次后再改变任务状态，通知主线程
				errorTimes++;
				if (errorTimes >= 3)
				{
					task.status = 'error';
					postMessage({cmd: 'statusChanged', task: task});
					lg.error(errorTimes + '次重试后依然上传错误，忽律上传任务[' + task.filePath + ']');
					lg = null;
					return;
				}
				else
				{
					lg.warn('上传任务[' + task.filePath + ']上传出错，休眠10秒后重试......');
					sleep(10 * 1000);
					// Atomics.wait(new Int32Array(new SharedArrayBuffer(2)), 0, 0, 5000);

					return uploadTrunk();
				}
			}
		});
	}
	catch (err)
	{
		task.status = 'error';
		postMessage({cmd: 'statusChanged', task: task});
		// 执行完成回调
		lg.error('文件上传失败：' + err.message);
		lg = null;
	}
}