/**
 * Forp大文件断点下载类
 *
 * Copyright © 2018 FORP Co., LTD
 * All Rights Reserved.
 */

// **注意**：Tiny-Worker只能执行NodeJs环境，普通Javascript语法无法执行

const fs = require('fs');
const request  = require('request');
const sleep = require('thread-sleep');
// Log4js
const log4js = require('log4js');
var lg = null;
// 全局变量
var FORP, task, trunkSize, fd, errorTimes = 0;

/**
 * 接收主线程消息
 */
onmessage = function(event)
{
	// log4js
	if (null == lg)
	{
		log4js.configure(JSON.parse(fs.readFileSync(event.data.dirname + '/log4js.conf')));
		lg = log4js.getLogger('file');
	}

	// FORP信息
	if (event.data.FORP)
	{
		FORP = event.data.FORP;
	}

	// task信息
	if (event.data.task)
	{
		task = event.data.task;
	}

	// 命令处理
	if ('start' == event.data.cmd)
	{
		lg.info('↓↓↓↓↓ ' + task.filePath + '[' + task.id + ']');
		downloadTrunk();
	}
	else if ('pause' == event.data.cmd)
	{
		// 暂停
		task.status = 'pause';
	}
	else if ('remove' == event.data.cmd)
	{
		// 删除
		task.status = 'remove';
	}
	else
	{
		lg.warn('无效的下载指令：' + event.data);
	}
}

/**
 * 下载文件片段
 */
function downloadTrunk()
{
	try
	{
		if ('running' != task.status)
		{
			lg.info('下载Worker结束运行[' + task.id + ']' + task.status);
			postMessage({cmd: 'statusChanged', task: task});
			lg = null;

			return;
		}
	
		// 分段下载
		if (task.position >= task.fileSize)
		{
			// 已下载完毕
			lg.info('文件下载成功：' + task.filePath + ' ' + task.fileSize + ' ' + 
			(task.finishTime - task.startTime) / 1000 + '秒 ' + (task.fileSize / ((task.finishTime - task.startTime) / 1000)) + '/秒');
	
			lg = null;
			task.status = 'finished';
			// 文件下载完成
			postMessage({cmd: 'finished', task: task});

			return;
		}
	
		lg.info('↓↓[' + task.id + ']:' + task.position + '->' + task.fileSize);
	
		// 发送HTTP请求
		var params =
		{
			url: FORP.host + '/fileassistant/download/' + task.id,
			headers: {'powed-by': 'Forp'}, method: 'POST', json: true,
			formData: {p1: FORP.p1, position: task.position, type: task.type}
		};
		request(params, function(err, rsp, body)
		{
			// lg.debug(body);
			if (body && body.code && 200 == body.code)
			{
				if (0 == task.position)
				{
					// 记录服务器端开始上传的时间：减去1秒模拟为客户端实际添加文件的时间，防止只有一段时用时为0的问题。
					task.startTime = parseInt(body.data.serverTime) - 100;
					task.fileSize = parseInt(body.data.fileSize);
				}
	
				// 更新服务器端的完成时间
				preFinishTime = task.finishTime;
				task.finishTime = parseInt(body.data.serverTime);
				if (-1 == preFinishTime)
				{
					preFinishTime = task.startTime;
				}
	
				trunkSize = parseInt(body.data.trunkSize);
				if (-1 == trunkSize)
				{
					// 导出项目资料：服务器正在压缩文件
					postMessage({cmd: 'progress', task: task, preFinishTime: preFinishTime, finished: trunkSize});
					lg.warn('导出文件压缩中，10秒后再重试...');
					sleep(10 * 1000);
					// Atomics.wait(new Int32Array(new SharedArrayBuffer(2)), 1, 0, 5000);
				}
				else
				{
					// 直接下载方式：保存文件
					fs.appendFileSync(task.filePath, Buffer.from(body.data.trunk, 'base64'), 'binary');
	
					// try
					// {
					// 	// lg.debug('保存文件片段：' + task.filePath);
					// 	// var ws = fs.createWriteStream(task.filePath, {encoding: 'binary'});	// , start: task.position
					// 	// ws.write(Buffer.from(body.data.trunk, 'base64'), 'binary');	// .toString('binary')
					// 	// if (false == ws.write(Buffer.from(body.data.trunk, 'base64')))
					// 	// {
					// 	// 	// 修改状态为Error，发送通知消息并退出运行
					// 	// 	lg.warn('文件片段保存失败！');
					// 	// 	return;
					// 	// }
					// 	// fd = fs.openSync(task.filePath, 'w');	// TODO 改为独占模式
					// 	// fs.writeSync(fd, Buffer.from(body.data.trunk, 'base64'), 0, trunkSize, task.position);
						
					// }
					// finally
					// {
					// 	// fs.closeSync(fd);
					// }
	
					// 后移文件上传进度
					task.position = task.position + trunkSize;
					postMessage({cmd: 'progress', task: task, preFinishTime: preFinishTime, finished: trunkSize});
				}
	
				return downloadTrunk();
			}
			else
			{
				// 重试3次后再改变任务状态，通知主线程
				errorTimes++;
				if (errorTimes >= 3)
				{
					task.status = 'error';
					postMessage({cmd: 'statusChanged', task: task});
					lg.error(errorTimes + '次重试后依然下载错误，忽律下载任务[' + task.filePath + ']');
					lg = null;

					return;
				}
				else
				{
					lg.warn('下载任务[' + task.filePath + ']下载出错，休眠10秒后重试......');
					sleep(10 * 1000);

					return downloadTrunk();
				}
			}
		});
	}
	catch (err)
	{
		task.status = 'error';
		postMessage({cmd: 'statusChanged', task: task});
		lg.error('文件下载失败：' + err.message);
		lg = null;
	}
}