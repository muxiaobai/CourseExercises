/**
 * Forp大文件断点下载类
 *
 * Copyright © 2018 FORP Co., LTD
 * All Rights Reserved.
 */

// **注意**：Tiny-Worker只能执行NodeJs环境，普通Javascript语法无法执行

const fs = require('fs');
const request  = require('request');
const sleep = require('thread-sleep');
// Log4js
const log4js = require('log4js');
log4js.configure(JSON.parse(fs.readFileSync(__dirname + '/resources/app/app/log4js.conf')));	// 只能在打包后环境中执行
const lg = log4js.getLogger('file');
// 全局变量
var FORP, task, trunkSize, fd, errorTimes = 0;

/**
 * 接收主线程消息
 */
onmessage = function(event)
{
	// FORP信息
	if (event.data.FORP)
	{
		FORP = event.data.FORP;
	}

	// task信息
	if (event.data.task)
	{
		task = event.data.task;
	}

	// 命令处理
	if ('start' == event.data.cmd)
	{
		lg.info('↓↓↓↓↓ ' + task.filePath + '[' + task.id + ']');
		downloadTrunk();
	}
	else if ('pause' == event.data.cmd)
	{
		// 暂停
		task.status = 'pause';
	}
	else if ('remove' == event.data.cmd)
	{
		// 删除
		task.status = 'remove';
	}
	else
	{
		lg.warn('无效的下载指令：' + event.data);
	}
}

/**
 * 下载文件片段
 */
function downloadTrunk()
{
	try
	{
		if ('running' != task.status)
		{
			lg.info('下载Worker结束运行[' + task.id + ']' + task.status);
			postMessage({cmd: 'statusChanged', task: task});
			return;
		}
	
		// 分段下载
		if (task.position >= task.fileSize)
		{
			// 已下载完毕
			lg.info('文件下载成功：' + task.filePath + ' ' + task.fileSize + ' ' + 
			(task.finishTime - task.startTime) / 1000 + '秒 ' + (task.fileSize / ((task.finishTime - task.startTime) / 1000)) + '/秒');
	
			task.status = 'finished';
			// 文件下载完成
			postMessage({cmd: 'finished', task: task});
			return;
		}
	
		lg.info('↓↓[' + task.id + ']:' + task.position + '->' + task.fileSize);
	
		// 发送HTTP请求 TODO 下载块大小不是后台设置的10M默认值，是255K
		var params =
		{
			url: FORP.host + '/fileassistant/download/' + task.id,
			headers: {'powed-by': 'Forp'}, method: 'POST', json: true,
			formData: {p1: FORP.p1, position: task.position, type: task.type}
		};
		request(params, function(err, rsp, body)
		{
			if (200 == rsp.statusCode && 200 == rsp.headers['code'])
			{
				if (0 == task.position)
				{
					// 记录服务器端开始上传的时间：减去1秒模拟为客户端实际添加文件的时间，防止只有一段时用时为0的问题。
					task.startTime = parseInt(rsp.headers['server-time']) - 100;
					task.fileSize = parseInt(rsp.headers['file-size']);
				}
	
				// 更新服务器端的完成时间
				preFinishTime = task.finishTime;
				task.finishTime = parseInt(rsp.headers['server-time']);
				if (-1 == preFinishTime)
				{
					preFinishTime = task.startTime;
				}
	
				trunkSize = parseInt(rsp.headers['trunk-size']);
				if (-1 == trunkSize)
				{
					// 导出项目资料：服务器正在压缩文件
					postMessage({cmd: 'progress', task: task, preFinishTime: preFinishTime, finished: trunkSize});
					lg.warn('导出文件压缩中，10秒后再重试...');
					sleep(10 * 1000);
					// Atomics.wait(new Int32Array(new SharedArrayBuffer(2)), 1, 0, 5000);
				}
				else
				{
					// 直接下载方式：保存文件
					var ws = fs.createWriteStream(task.filePath, {flags: 'a+'});	// , start: task.position
					ws.write(body);
					// fs.appendFileSync(task.filePath, body, 'utf-，8');
	
					// try
					// {
					// 	// lg.debug('保存文件片段：' + task.filePath);
					// 	// var ws = fs.createWriteStream(task.filePath, {encoding: 'binary'});	// , start: task.position
					// 	// ws.write(Buffer.from(body.data.trunk, 'base64'), 'binary');	// .toString('binary')
					// 	// if (false == ws.write(Buffer.from(body.data.trunk, 'base64')))
					// 	// {
					// 	// 	// 修改状态为Error，发送通知消息并退出运行
					// 	// 	lg.warn('文件片段保存失败！');
					// 	// 	return;
					// 	// }
					// 	// fd = fs.openSync(task.filePath, 'w');	// TODO 改为独占模式
					// 	// fs.writeSync(fd, Buffer.from(body.data.trunk, 'base64'), 0, trunkSize, task.position);
						
					// }
					// finally
					// {
					// 	// fs.closeSync(fd);
					// }
	
					// 后移文件上传进度
					task.position = task.position + trunkSize;
					postMessage({cmd: 'progress', task: task, preFinishTime: preFinishTime, finished: trunkSize});
				}
	
				return downloadTrunk();
			}
			else
			{
				// 重试3次后再改变任务状态，通知主线程
				errorTimes++;
				if (errorTimes >= 3)
				{
					task.status = 'error';
					postMessage({cmd: 'statusChanged', task: task});
					lg.error(errorTimes + '次重试后依然下载错误，忽律下载任务[' + task.filePath + ']');
					return;
				}
				else
				{
					lg.warn('下载任务[' + task.filePath + ']下载出错，休眠5秒后重试......');
					sleep(5 * 1000);
					return downloadTrunk();
				}
			}
		});
	}
	catch (err)
	{
		task.status = 'error';
		postMessage({cmd: 'statusChanged', task: task});
		lg.error('文件下载失败：' + err.message);
	}
}